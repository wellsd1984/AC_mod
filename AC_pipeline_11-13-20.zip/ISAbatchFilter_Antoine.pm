#!/usr/bin/perl

# ISAbatchFilter.pm
# Dr. Xiaolin Wu & Daria W. Wells

# This module contains the subroutines that process the demultiplexed and pair-matched 
# ISA data and generates fasta files for alignment.

package ISAbatchFilter_Antoine; 

use 5.18.4;

use strict;
use warnings;

use Exporter qw(import);
use IO::Zlib;
use Data::Dumper;

our @EXPORT_OK = qw(batch_filter_1_internal batch_filter_2_length20 batch_filter_3_q20 make_unique_pair_fasta);




		
# If an internal sequence is defined, this subroutine reads the copied original data file and
# remove the reads that contain that sequence immediately after the LTR junction.
	

# This subroutine filters out the reads where the post-LTR sequence is shorter than 20 bases.

sub batch_filter_2_length20 {

	# Initialize variables
	my ($data_file,$LTR,$folder,$linker) = @_;	
	my $all_reads = my $too_short = my $passing = 0;
	
	# Obtain the LTR junction sequence from the primer file generated in the demultiplex step.
	# Change it to the reverse complement for matching to read 2.
	my $jct_file = "$LTR/$LTR"."_primer.txt";
	open my $jct_in, "<", $jct_file or die "$!: $jct_file";
	<$jct_in>;
	my $junction = <$jct_in>;
	close $jct_in;
	foreach($junction, $linker) {	
		$_ = reverse $_;
		$_ =~ tr/ATGC/TACG/;
	}
	
	my $data_in;
	# Open the file handle to read the data. First check if the data file is a .gz
	# file and open appropriately.
	if ($data_file =~ m/\.gz$/) {
		open($data_in, "gzip -dc $data_file |") or die "Unable to open the data file in filter 2: length >= 20 bp. $data_file $!\n";
	}else {
		open $data_in, "<", "$data_file" or die "Unable to open the data file in filter 2: length >= 20 bp. $!\n";
	}
	open my $data_out, ">", "$folder/PEread_LTR_NonInternal_linker_long.txt" or die "Unable print to new file in filter 2: length >= 20 bp. $! $data_file\n";
	
	print "Removing post-LTR sequences shorter than 20 bases...\n";
	
	
	# Test each for the length of the post LTR sequence. Print the lines to a new file if
	# the post LTR sequence is 20 bases or longer.
	while (my $line_in = <$data_in>) {
		$all_reads++; # Count all of the reads imported.
		# Obtain the post-LTR sequence (read 1) and the post-linker sequence (read 2)
		my @line_elements = split/\t/, $line_in;
		my ($R1insert,$R2insert) = @line_elements[3,8];
		
		# First remove any reverse complement linker sequence from read 1 ($line_elements[3]) and any reverse
		# complement LTR sequence from read 2 ($line_elements[8])
		$line_elements[3] =~ s/(.*)$linker.*/$1/; # First remove any reverse complement linker sequence from read 1
		$line_elements[8] =~ s/(.*)$junction.*/$1/; # Remove any reverse complement LTR sequence from read 2

		# Only accept pairs where both the post-LTR sequence and the post-Linker sequence are at least 20 bp.
		if(length $line_elements[3]<20 or length $line_elements[8]<20) { # If the sequence is too short, skip it and track it.
		
			$too_short++; # Count the number of rejected pairs.
			
		}else { # If the sequence is long enough, print it and track it.
			my $line_out = join("\t", @line_elements);
			print $data_out $line_out; # Print the lines that are at least 20 bases
			$passing++; # Count the long enough read pairs
		}
	}
	close $data_in;
	close $data_out;
	
	# Report the number of too short and long enough reads to the log.
	open my $log_fh, ">>", "$folder/blat_log.txt" or die "Unable to print to log file in batch filter 2: length >= 20. $!";
	print $log_fh "Filtering read pairs by length\nPairs analyzed:\t$all_reads\n\tFiltered pairs <20bp:\t$too_short\n\tPassed pairs >=20bp:\t$passing\n\n";
	close $log_fh;

	# Delete interim report.
 	unlink "$folder/$data_file";
	return;
}

##########################################################################################################################

# This subroutine will filter out the low quality reads, defined as reads whose q20
# score is less than 20.

sub batch_filter_3_q20 {
	
	my ($LTR,$folder) = @_;
	
	open my $data_in, "<$folder/PEread_LTR_NonInternal_linker_long.txt" or die "Unable to open the data file in filter 3: q20 > 20. $!\n";
	open my $data_out, ">$folder/PEread_LTR_NonInternal_linker_long_q20.txt" or die "Unable print to new file in filter 3: q20 > 20. $!\n";

	print "Removing low quality sequences...\n";

	# Initialize variables
	my $qcutoff = 20;
	my $totalin = my $totalout = my $filtered = 0;

	# Iterate through the data. 
	while (my $newline = <$data_in>) {
	
		# Compare each read separately
		my $sumL=0;
		my $sumR=0;
		
		$totalin++; # Count the number of reads imported
		my @elesnew = split(/\t/, $newline); # Split the input line into its component parts
		my $LTR = $elesnew[2]; # Obtain the HIV LTR sequence from read 1
		my $insertL = $elesnew[3];  # Obtain the post-LTR sequence from read 1
		my $qscoreL = $elesnew[4];  # Obtain the quality score for the post-LTR sequence
		
		# Calculate the quality score of the first 20 bp of the post-LTR sequence
		my $LTRlen = length($LTR); # Obtain the length of the HIV LTR sequence
		# Obtain the quality score of the first 20 post-LTR sequence by skipping bases equal to the HIV LTR length
		my $insertqscore20bpL = substr $qscoreL, $LTRlen, 20;
		
		# Convert the read1 quality score to an array
		my @qscoresL = split(//,$insertqscore20bpL);
		# Convert each ascii to numerical value and calculate average, A=65
		foreach(@qscoresL) {
			my $qL=ord($_);
			$sumL += $qL;
		}
		my $averageqscore20bpL = $sumL/20-33;  #start from ASCII 33 in Illumina new version
		# Source: wikipedia Fastq_format, older version -64
		
		# Get the quality score of post-linker sequence
		my $insertR = $elesnew[8]; # Obtain the post-linker sequence from read 2
		# Obtain the quality score of the first 20 post-linker sequence by skipping bases equal to the linker length
		my $qscoreR = substr $elesnew[9], 35, 20;
		# Convert the read2 quality score to an array
		my @qscoresR = split(//, $qscoreR);
		# Convert each ascii to numerical value and calculate average, A=65
		foreach(@qscoresR) {
			my $qR = ord($_);
			$sumR += $qR;
		}
		my $averagescore20bpR = $sumR/20-33; #start from ASCII 33 in Illumina new version

		# Determine if both reads have acceptable Q scores		
		if($averageqscore20bpL>$qcutoff and $averagescore20bpR>$qcutoff) {
			$totalout++; # Count the passing reads
			print $data_out $newline; # Print the passing reads
		}else{$filtered++;} # Count the removed reads
	}

	close $data_in;
	close $data_out;
	
	# Report the number of reads remaining
	open my $log_fh, ">>$folder/blat_log.txt" or die "Unable to print to log file in filter 3: q20 > 20. $!\n";
	print $log_fh "Filtering read pairs by quality score\nPairs analyzed:\t$totalin\n\tFiltered low-quality pairs:\t$filtered\n\tHigh-quality long pairs:\t$totalout\n\n";
	close $log_fh;
	
 	unlink "$folder/PEread_LTR_NonInternal_linker_long.txt";

	# Delete interim report.
	return;
}

##########################################################################################################################

# This subroutine prepares fasta files for BLAT alignment. The first 15 bases of the post-LTR
# sequence and the post-linker sequence are used to create a unique "tag" to identify 
# identical PCR products and the number of times each unique pair is seen counted. A forward
# and a reverse fasta file are created.

sub make_unique_pair_fasta {

	my ($LTR,$folder) = @_;
	open my $data_in, "<$folder/PEread_LTR_NonInternal_linker_long_q20.txt" or die "Unable to open the data file in filter 4: generate fasta $!\n";
	
	print "Identifying unique inserts...\n";
	
	# Initialize variables
	my $total_unique = my $all_reads = 0; # Count the total number of read pairs analyzed and how many of them are unique
	
	# Store the unique pairs and their data in hashes
	my (%unique, %unique_count);

	# Iterate through the data to search for unique pairs
	while (my $line = <$data_in>) {
		$all_reads++; # Count all pairs analyzed
		chomp($line);
		my @elements=split /\t/, $line; # Split the input line into it's component parts
		
		# Obtain the relevant parts and modify as necessary
		my $LTR_seq = $elements[3]; # Obtain the post-LTR read 1 sequence
		my $Linker_seq = $elements[8]; # Obtain the post-linker read 2 sequence
		# Create an identifier ($tag) for each unique read by combining the first 15 bases each of $LTR_seq_end and $Linker_seq_end
		my $LTR_seq_end = substr($LTR_seq, 0, 15);
		my $Linker_seq_end = substr($Linker_seq, 0, 15);
		my $tag="$LTR_seq_end$Linker_seq_end";
		
		if (!exists $unique{$tag}) {
			$unique{$tag} = $line;
			$unique_count{$tag} = 0;
			$total_unique++;
		}
		$unique_count{$tag}++;
	}
	close $data_in;
	
	# Delete interim report.
 	unlink "$folder/PEread_LTR_NonInternal_linker_long_q20.txt";

	# Print the unique pairs without their LTR and linker sequences
	my $unique_reads_output = "./$folder/unique_paired-end_reads.txt";
	my $read1_fasta_file = "$folder/read1_fasta_for_alignment.fa";
	my $read2_fasta_file = "$folder/read2_fasta_for_alignment.fa";
	
	open my $out_counts,'>', $unique_reads_output or die "Unable to print the unique pairs to $unique_reads_output in filter 4: $!\n";
	open my $outL, '>', $read1_fasta_file or die "Unable to print the read1 fasta file in filter 4: $!\n";
	open my $outR, '>', $read2_fasta_file or die "Unable to print the read2 fasta file in filter 4: $!\n";
	
	print "Generating fasta files...\n";
	
	foreach my $tag (keys %unique) {
		
		my @unique_line_elements = split /\t/, $unique{$tag};
		$unique_line_elements[0] .= "#$unique_count{$tag}";
		my $new_line_out = join("\t", @unique_line_elements);
		
		print $out_counts "$new_line_out\n"; # Print the unique reads with their attached counts to an interim report
		print $outL ">$unique_line_elements[0]\n$unique_line_elements[3]\n"; # Print the read 1 sequences to a fasta file
		print $outR ">$unique_line_elements[0]\n$unique_line_elements[8]\n"; # Print the read s sequences to a fasta file
	}
		
	
	close $out_counts;
	close $outL;
	close $outR;
	
	open my $log_fh, ">>$folder/blat_log.txt" or die "Unable to print to log file in filter 4: generate fasta. $!\n";
	print $log_fh "Count and merge unique read pairs for alignment\nPairs analyzed:\t$all_reads\n\tUnique, long, high-quality pairs: $total_unique\n\n";
	close $log_fh;
	
	return;
}

1;