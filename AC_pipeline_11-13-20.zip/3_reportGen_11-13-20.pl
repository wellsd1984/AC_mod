#!/usr/bin/perl

# 3_generate_standard_report.pl
# Daria W. Wells & Dr. Shuang Guo

# This script imports the ISA pipeline results, adds gene coordinates and other genetic
# information, and prints the data to a new report file in the standardized ISA report
# format. It is intended to be used after manually reviewing and filtering the ISA pipeline results.

use 5.18.4;

use strict;
use warnings;

use File::Basename;
use Getopt::Long qw(GetOptions);
Getopt::Long::Configure qw(gnu_getopt);

BEGIN 
{
	my $dirname = dirname(__FILE__);
	unshift @INC, $dirname;
}

use ISAgeneAnnotation;

our ($opt_LTR, $opt_linker, $opt_genes, $opt_data);
GetOptions(
	'LTR=s' => \$opt_LTR,
	'linker=s' => \$opt_linker,
	'f=s' => \$opt_data,
	'g=s' => \$opt_genes,
);
	
my $output_file = $opt_data;

$output_file =~ s/\.txt$/_with_gene.txt/;
say "'$output_file' already exists" and exit if -e $output_file;
say "No input files specified." and exit unless $opt_data;
say "No reference genes file specifed" and exit unless $opt_genes;	

# Get the reverse complements of the junction and linker sequences. Used for trimming the reads.
my $LTR_junctions_reverse_comp = $opt_LTR;
$LTR_junctions_reverse_comp = reverse($LTR_junctions_reverse_comp);
$LTR_junctions_reverse_comp =~ tr/ATGC/TACG/;
my $linker_reverse_comp = $opt_linker;
$linker_reverse_comp = reverse($linker_reverse_comp);
$linker_reverse_comp =~ tr/ATGC/TACG/;



# Import the reference gene coordinates.
open my $ref_genes, "<", $opt_genes or die;

# Store and sort each line of the reference file by chromosome for faster searching.
my %chromosome_genes;

while (my $line = <$ref_genes>) {
	chomp($line);
	my @elements = split(/\t/, $line);
	my $chromosome = $elements[2];
	$chromosome =~ s/chr//;
	$chromosome_genes{$chromosome} = [] unless exists $chromosome_genes{$chromosome};
	push @{$chromosome_genes{$chromosome}}, $line;
}

# Create the header for the final output report.
my $header = "IS_chr\tIS_strand\tIS_base\tBP_chr\tBP_strand\tBP_base\tlength\tproviral-orientation-chr-virus5-3\tLTR\tpseudo3LTRchr\tpseudostrand\tpseudo3LTRbp\tpseudoCombo\tGeneName\tIn/Out\tIntron/Exon/Distance_to_nearestGene\tRefID\tGeneStrand\tTxStart\tTxEnd\tbreakpoint_count\tread_count\texample_seq_ID\tupstream_30bp\tdownstream_30bp\tread1_index\tread1_trimmed\tread2_index\tread2_trimmed";

# Open data input file.
open my $data_in, "<", $opt_data or die "$!\n";
<$data_in>; # Skip the header line.

# The number of breakpoints per integration site needs to be counted, but the count goes in
# a middle column. Store the output as separate scalars then put them together with the
# breakpoint counts in the middle. Store the halves in hashes sorted by PID.
my @output_data_lines_first_halves;
my @output_data_lines_second_halves;


# The keys of %breakpoint_count are the pseudo LTRs. The values of %breakpoint_count are 
# keys to another has with lengths as keys. Count the number of length keys for each pseudo
# 3LTR to get the number of breakpoints.
my %breakpoint_count;

# Iterate through the data lines.
foreach my $line (<$data_in>) {
	next if $line !~ m/\w/;
	chomp($line);
	my @elements = split /\t/, $line;	# Split each line into its component parts.
	my $pseudo_3LTR = $elements[9]; # Assign the pseudo 3LTR integration site to a scalar.
	my ($pseudo_chr, $pseudo_strand, $pseudo_base) = ($pseudo_3LTR =~ m/chr(\w+)(-|\+)(\d+)/); # Assign the IS chromosome and base by splitting at the IS pseudo 3LTR. Save the strand.
	my $HIV_LTR = $elements[10]; # Assign the LTR to a scalar.
	my $read_count = $elements[0]; # Assign the read count to a scalar.
	my $seq_ID = $elements[1]; # Assign the sequence ID to a scalar.
	my $orientation_to_chr = $elements[11]; # Assign the provirus orientation relative to the reference genome to a scalar.
	my $length = $elements[8]; # Assign the host fragment length to a scalar.
	my $read1 = $elements[15]; # Assign the read1 sequence to a scalar.
	my $read2 = $elements[16]; # Assign the read2 sequence to a scalar.
	
	# Create new scalars containing the read1 and read2 sequence with the HIV LTR and linker sequences removed.
	my $read1_trimmed = $read1; 
	$read1_trimmed =~ s/.*?($opt_LTR)//;
	$read1_trimmed =~ s/($linker_reverse_comp).*//;
	my $read2_trimmed = $read2; 
	$read2_trimmed =~ s/.*?($opt_linker)//;
	$read2_trimmed =~ s/($LTR_junctions_reverse_comp).*//;
	
	# Create a scalar containing the relevant host and NGS sequences separated by a tab.
	my $ref_genomic_and_illumina_bases = join("\t", @elements[13..14], $read1, $read1_trimmed, $read2, $read2_trimmed);
	# Create a scalar containing the integration site and breakpoint locations and strands and the length of the fragment separated by a tab.
	my $IS_and_BP_info = join("\t", @elements[2..8]);

	my $target_gene = find_target_gene($pseudo_chr, $pseudo_strand, $pseudo_base, \%chromosome_genes);
	
	
	# Create the first and second halves of the output lines.
	my $line_first_half = "$IS_and_BP_info\t$orientation_to_chr\t$HIV_LTR\t$pseudo_chr\t$pseudo_strand\t$pseudo_base\t$pseudo_3LTR\t$target_gene";
	my $line_second_half = "$read_count\t$seq_ID\t$ref_genomic_and_illumina_bases";
	
	push @output_data_lines_first_halves, $line_first_half;
	push @output_data_lines_second_halves, $line_second_half;
	
	# Add the length to %{breakpoint_count{$pseudo_3LTR}} as a key for counting unique breakpoints.
	$breakpoint_count{$pseudo_3LTR}{$length} = 0;
	
}

close $data_in;

# Obtain the breakpoint counts, put the final lines together, and print to a file.
open my $data_out, ">", $output_file;
print $data_out $header."\n";

for (my $i = 0; $i < @output_data_lines_first_halves; $i++) {

	$output_data_lines_first_halves[$i] =~ m/(chr\w+\W\d+)/; # Obtain the pseudo 3LTR from the end of the first half of the output.
	my $pseudo_3LTR = $1;
	my $number_of_BP = keys %{$breakpoint_count{$pseudo_3LTR}}; # Count the number of breakpoints (unique integration events).
	print $data_out "$output_data_lines_first_halves[$i]\t$number_of_BP\t$output_data_lines_second_halves[$i]\n";
}



close $data_out;



##############################################
sub find_target_gene {
	my ($chromosome, $strand, $coordinate, $chromosome_genes)= @_;

	################################findnearest gene and print OUT
	my $coordinate30kbup = $coordinate -30000;
	my $coordinate30kbdown = $coordinate +30000;
	
	my $in_or_near = "out";
	my $distance2nearestgene = "100000000";
	my $target_gene;
	my $gene_name2;
	my $distance;
	my $nearest_gene;

	#check for each gene on the chr
	foreach my $ref_gene (@{$chromosome_genes{$chromosome}}) {
		my @annotations = split(/\t/, $ref_gene);
		my $refID = $annotations[1];
		my $txstrand = $annotations[3];
		my $txstart = $annotations[4];
		my $txend = $annotations[5];
		my $gene_name = $annotations[12];
		
		if ($coordinate > $txstart and $coordinate < $txend) {
			#this RIS is in this gene
			$in_or_near = "in";
			
			my $exon_num = $annotations[8];
			my $exon_start = $annotations[9];
			my $exon_end = $annotations[10];
			
			my @exon_starts = split(/\,/, $exon_start);
			my @exon_ends= split(/\,/, $exon_end);
			
			my $exon_or_intron = "intron";
			for(my $i = 0; $i<$exon_num; $i++) {  #check to see if in each exon
				if($coordinate > $exon_starts[$i] and $coordinate < $exon_ends[$i]) {
					#this RIS is in this Exon
					$exon_or_intron = "exon";
				}
			}
			
			$target_gene="$gene_name\t$in_or_near\t$exon_or_intron\t$refID\t$txstrand\t$txstart\t$txend";
		}
		else {
			#this RIS is outside of this gene, then calculate the distance from txStart and txEnd
			my $distance2txstart = abs($txstart - $coordinate);
			my $distance2txend = abs($txend - $coordinate);
			if($distance2txstart > $distance2txend) {
				$distance = $distance2txend;
			}
			else {$distance = $distance2txstart;}
			
			if($distance < $distance2nearestgene) {
				$distance2nearestgene = $distance;
				$nearest_gene = "$refID\t$txstrand\t$txstart\t$txend";
				$gene_name2 = $gene_name;
			}
		}
	}
	
	#at the end of checking for all genes, choose the nearest one.
	if($in_or_near eq "out") {
		$target_gene="$gene_name2\t$in_or_near\t$distance2nearestgene\t$nearest_gene";
	}
	return ($target_gene);

}